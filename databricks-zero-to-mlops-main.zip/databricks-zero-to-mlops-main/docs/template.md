
# Week 2

## Workshop A:  

### Section 1:  
* [slides]

#### References
* 

### Section 2:  
* [slides]

#### References
* 
* 


### Section 3: 
* [slides]

#### References
* 

## Workshop B: 

### Section 1:  
* [slides]

#### References
* 

### Section 2: 
* [slides]

#### References

### Section 3:  
* [slides]
#### References

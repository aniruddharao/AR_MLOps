# Week 1

## Create Cluster

### Spot Type
![1-1-Create-Clusters](https://user-images.githubusercontent.com/58792/155761550-9d0332fe-a446-424a-8e5b-aa43f1ee18ba.png)

### No Spot Type
![1-2-Create-Clusters-no-spot](https://user-images.githubusercontent.com/58792/155763952-d66ebeca-2220-40c0-8c9f-31852d1f4a8e.png)

### Single Node
![1-3-Create-Cluster-Single-Node](https://user-images.githubusercontent.com/58792/155767149-01fb6764-03d3-4bbb-84b2-baf2b98b4db9.png)

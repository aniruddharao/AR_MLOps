## Getting Started with Databricks and Spark

### Launching and Managing Clusters
